"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.processData = void 0;
const AWSXRay = __importStar(require("aws-xray-sdk-core"));
const AWS = __importStar(require("aws-sdk"));
const uuid_1 = require("uuid");
// Instrumentar AWS SDK com X-Ray
AWS.config.update({ region: process.env.AWS_REGION || "us-east-1" });
const AWSWithXRay = AWSXRay.captureAWS(AWS);
const dynamodb = new AWSWithXRay.DynamoDB.DocumentClient();
const processData = async (event, context) => {
    // Obter trace ID do X-Ray
    const segment = AWSXRay.getSegment();
    const traceId = segment
        ? segment.trace_id || context.awsRequestId
        : context.awsRequestId;
    console.log("🚀 Iniciando processamento de dados", {
        traceId,
        requestId: context.awsRequestId,
        timestamp: new Date().toISOString(),
    });
    // Adicionar annotations iniciais
    if (segment) {
        segment.addAnnotation("requestId", context.awsRequestId);
        segment.addAnnotation("httpMethod", event.httpMethod);
        segment.addAnnotation("stage", process.env.STAGE || "dev");
        segment.addMetadata("request", {
            headers: event.headers,
            queryParams: event.queryStringParameters,
            pathParams: event.pathParameters,
            userAgent: event.headers?.["User-Agent"] || "unknown",
        });
    }
    try {
        // Validar se o body existe
        if (!event.body) {
            console.error("❌ Body da requisição não encontrado");
            // Adicionar annotations para body ausente
            if (segment) {
                segment.addAnnotation("success", false);
                segment.addAnnotation("errorType", "MissingBody");
                segment.addMetadata("requestError", {
                    issue: "Missing request body",
                    timestamp: new Date().toISOString(),
                });
            }
            return createResponse(400, "Body da requisição é obrigatório", traceId);
        }
        // Parse do JSON
        let userData;
        try {
            const parsedBody = JSON.parse(event.body);
            userData = {
                id: (0, uuid_1.v4)(),
                name: parsedBody.name,
                email: parsedBody.email,
                age: parsedBody.age,
                city: parsedBody.city,
                country: parsedBody.country,
                timestamp: new Date().toISOString(),
            };
        }
        catch (parseError) {
            console.error("❌ Erro ao fazer parse do JSON:", parseError);
            // Adicionar annotations para erro de parse
            if (segment) {
                segment.addAnnotation("success", false);
                segment.addAnnotation("errorType", "ParseError");
                segment.addMetadata("parseError", {
                    error: parseError.message,
                    rawBody: event.body,
                    timestamp: new Date().toISOString(),
                });
            }
            return createResponse(400, "JSON inválido", traceId);
        }
        // Validações de negócio
        const validationErrors = validateUserData(userData);
        if (validationErrors.length > 0) {
            console.error("❌ Dados inválidos:", validationErrors);
            // Adicionar annotations para erro de validação
            if (segment) {
                segment.addAnnotation("success", false);
                segment.addAnnotation("errorType", "ValidationError");
                segment.addAnnotation("validationErrorCount", validationErrors.length);
                segment.addMetadata("validation", {
                    errors: validationErrors,
                    inputData: userData,
                    timestamp: new Date().toISOString(),
                });
            }
            return createResponse(400, `Dados inválidos: ${validationErrors.join(", ")}`, traceId);
        }
        console.log("✅ Dados validados com sucesso", {
            userId: userData.id,
            name: userData.name,
            email: userData.email,
        });
        // Salvar no DynamoDB (já instrumentado pelo X-Ray)
        const params = {
            TableName: process.env.DYNAMODB_TABLE,
            Item: userData,
        };
        console.log("💾 Salvando dados no DynamoDB", {
            tableName: params.TableName,
            userId: userData.id,
        });
        await dynamodb.put(params).promise();
        console.log("✅ Dados salvos com sucesso no DynamoDB");
        // Adicionar anotações detalhadas ao trace
        const currentSegment = AWSXRay.getSegment();
        if (currentSegment) {
            // Annotations (indexáveis no X-Ray)
            currentSegment.addAnnotation("userId", userData.id);
            currentSegment.addAnnotation("userCountry", userData.country);
            currentSegment.addAnnotation("userAgeGroup", getAgeGroup(userData.age));
            currentSegment.addAnnotation("userCity", userData.city);
            currentSegment.addAnnotation("operation", "user_registration");
            currentSegment.addAnnotation("success", true);
            // Metadatas (não indexáveis, mas visíveis no trace)
            currentSegment.addMetadata("user", {
                id: userData.id,
                name: userData.name,
                email: userData.email,
                age: userData.age,
                city: userData.city,
                country: userData.country,
                ageGroup: getAgeGroup(userData.age),
                timestamp: userData.timestamp,
            });
            currentSegment.addMetadata("processing", {
                validationPassed: true,
                dynamodbTable: process.env.DYNAMODB_TABLE,
                processingStartTime: new Date().toISOString(),
            });
        }
        // Métricas customizadas para CloudWatch
        await publishCustomMetrics(userData);
        console.log("🎉 Processamento concluído com sucesso", {
            userId: userData.id,
            processingTime: Date.now(),
        });
        return createResponse(200, "Dados processados com sucesso", traceId, {
            id: userData.id,
            message: "Usuário criado com sucesso",
        });
    }
    catch (error) {
        console.error("💥 Erro interno do servidor:", error);
        // Adicionar erro ao trace do X-Ray
        const errorSegment = AWSXRay.getSegment();
        if (errorSegment) {
            errorSegment.addError(error);
            errorSegment.addAnnotation("success", false);
            errorSegment.addAnnotation("errorType", error.name || "UnknownError");
            errorSegment.addMetadata("error", {
                message: error.message,
                stack: error.stack,
                timestamp: new Date().toISOString(),
            });
        }
        return createResponse(500, "Erro interno do servidor", traceId);
    }
};
exports.processData = processData;
function validateUserData(userData) {
    const errors = [];
    if (!userData.name || userData.name.trim().length < 2) {
        errors.push("Nome deve ter pelo menos 2 caracteres");
    }
    if (!userData.email || !userData.email.includes("@")) {
        errors.push("Email deve ser válido");
    }
    if (!userData.age || userData.age < 0 || userData.age > 120) {
        errors.push("Idade deve estar entre 0 e 120 anos");
    }
    if (!userData.city || userData.city.trim().length < 2) {
        errors.push("Cidade deve ter pelo menos 2 caracteres");
    }
    if (!userData.country || userData.country.trim().length < 2) {
        errors.push("País deve ter pelo menos 2 caracteres");
    }
    return errors;
}
async function publishCustomMetrics(userData) {
    const cloudwatch = AWSXRay.captureAWSClient(new AWS.CloudWatch());
    try {
        const params = {
            Namespace: "Workshop/UserData",
            MetricData: [
                {
                    MetricName: "UserRegistration",
                    Value: 1,
                    Unit: "Count",
                    Dimensions: [
                        {
                            Name: "Country",
                            Value: userData.country,
                        },
                        {
                            Name: "AgeGroup",
                            Value: getAgeGroup(userData.age),
                        },
                    ],
                    Timestamp: new Date(),
                },
                {
                    MetricName: "UserAge",
                    Value: userData.age,
                    Unit: "None",
                    Dimensions: [
                        {
                            Name: "Country",
                            Value: userData.country,
                        },
                    ],
                    Timestamp: new Date(),
                },
            ],
        };
        await cloudwatch.putMetricData(params).promise();
        console.log("📊 Métricas customizadas enviadas para CloudWatch");
    }
    catch (error) {
        console.error("❌ Erro ao enviar métricas customizadas:", error);
        // Não falhar a requisição por causa das métricas
    }
}
function getAgeGroup(age) {
    if (age < 18)
        return "Menor";
    if (age < 30)
        return "Jovem";
    if (age < 50)
        return "Adulto";
    if (age < 65)
        return "Maduro";
    return "Idoso";
}
function createResponse(statusCode, message, traceId, data) {
    const response = {
        statusCode,
        message,
        traceId,
        ...(data && { data }),
    };
    return {
        statusCode,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "X-Trace-Id": traceId,
        },
        body: JSON.stringify(response),
    };
}
//# sourceMappingURL=handler.js.map