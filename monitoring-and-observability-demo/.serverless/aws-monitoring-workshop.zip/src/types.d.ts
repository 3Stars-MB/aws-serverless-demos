export interface UserData {
    id: string;
    name: string;
    email: string;
    age: number;
    city: string;
    country: string;
    timestamp: string;
}
export interface ApiResponse {
    statusCode: number;
    message: string;
    data?: any;
    traceId?: string;
}
//# sourceMappingURL=types.d.ts.map