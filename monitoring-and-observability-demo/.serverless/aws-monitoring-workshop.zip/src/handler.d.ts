import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from "aws-lambda";
export declare const processData: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=handler.d.ts.map